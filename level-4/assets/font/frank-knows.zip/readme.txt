This font is free for commercial use and you are encouraged to make a donation to the koala hospital in NSW if you wish:

https://www.koalahospital.org.au

Sincerely
Christopher
